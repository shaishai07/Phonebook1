package com.slothdeboss.phonebook.ui

interface OnContactClicked {

    fun onClick(id: Long)

}